#include "FiguraGeometrica.h"
/*! Figura Geometrica